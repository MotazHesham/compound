<?php

return [
    'add' => 'add a new',
    'edit' => 'edit',
    'delete' => 'delete',
    'delete_marked' => 'delete marked',
    'save'=>'save',
    'close'=>'close',
    'addedSuccess'=>'Data added successfully',
    'editedSuccess'=>'Data updated successfully',
    'deleteSuccess'=>'Data deleted successfully',
    'sure'=>'Are you sure ?',
    'progress'=>'processing your request',
    'wait'=>'please wait',
    'options'=>'options',
    'choose'=>'choose',
    'other_details'=>'other details',
    'status'=>'Status',
    'details'=>'details',
    'sendMailSuccess'=>'Email send successfully',
];