
@if($language == 'ar')

    الكود هو :  {{$code}}
    @else
    the code is : {{$code}}
@endif