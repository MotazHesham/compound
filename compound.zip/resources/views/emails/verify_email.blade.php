
    <a href="http://api.shoohna.com/api/Auth_general/check_virfuy/{{$id}}"> @if($language=='ar') اضغط هنا  @else click here @endif</a>