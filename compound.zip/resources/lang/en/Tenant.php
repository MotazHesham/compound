<?php

return [
    'myFamily' => 'my family',
    'myOrders' =>'my orders',
    'OrderNew'=>'new',
    'OrderSuper'=>'under review',
    'OrderTech'=>'Accepted',
    'OrderProgress'=>'in Progress',
    'OrderDone'=>'completed',
    'OrderCancel'=>'cancel',
    'completed'=>'completed',
    'canceled'=>'canceled'
];