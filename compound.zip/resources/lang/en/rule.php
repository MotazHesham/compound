<?php

return [
	'required' => ' Field Is Required',
	'unique' => 'Field Please Insert Unique Value'
];