<script src="/Admin/assets/extra-libs/DataTables/datatables.min.js"></script>
<script src="/Admin/dist/js/pages/datatable/datatable-basic.init.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>

@include('Admin.includes.scripts.FormsHelper')
@include('Admin.includes.scripts.AlertHelper')
