<?php

return [
    'verification_email'=>'كود التفعيل',
    'forget_password'=>'اعادة كلمة السر'
];