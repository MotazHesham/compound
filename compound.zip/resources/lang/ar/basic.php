<?php

return [
    'add'=>'اضافة',
    'delete_marked' => 'حذف المحدد',
    'edit'=>'تعديل',
    'delete'=>'حذف',
    'save'=>'حفظ',
    'close'=>'اغلاق',
    'addedSuccess'=>'تمت الاضافة بنجاح',
    'editedSuccess'=>'تم التعديل بنجاح',
    'deleteSuccess'=>'تم الحذف بنجاح',
    'sure'=>'هل انت متاكد ؟',
    'progress'=>'الطلب قيد التنفيذ',
    'wait'=>'برجاء الانتظار',
    'options'=>'الاختيارات',
    'choose'=>'اختار',
    'other_details'=>'مواصفات اخرى',
    'status'=>'الحالة',
    'details'=>'التفاصيل',
    'sendMailSuccess'=>'تم ارسال الايميل بنجاح',

];