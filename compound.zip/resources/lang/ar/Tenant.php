<?php

return [
    'myFamily' => 'المراقبين',
    'myOrders' =>'طلباتي',
    'OrderNew'=>'جديد ',
    'OrderSuper'=>'تحت المراجعه',
    'OrderTech'=>'مقبول',
    'OrderProgress'=>'قيد التنفيذ',
    'OrderDone'=>'مكتمل',
    'OrderCancel'=>'ملغي',
    'OrderRate'=>'تم التقييم',
    'completed'=>'مكتملة',
    'canceled'=>'ملغية'

];