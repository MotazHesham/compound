<?php

return [

	'Email_address'=> 'البريد الالكتروني',



];
