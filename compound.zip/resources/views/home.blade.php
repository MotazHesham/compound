@extends('Fronted.layouts.master')

@section('title')
    الرئيسية
    @endsection

@section('content')
@endsection