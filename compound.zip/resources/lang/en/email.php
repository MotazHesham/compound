<?php

return [
    'verification_email'=>'verification code',
    'forget_password'=>'reset password'
];